package colas;
import java.util.Scanner;
import java.util.Scanner;

public class Principal {
	
	///queria  nose como pe una pila de numeros objeto increemntar los mayores

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CSNormal x=new CSNormal(100);
		int n;Object da;
		
		Scanner lee=new Scanner(System.in);
		System.out.println("Ingrese nro elem");
		n=lee.nextInt();
		for (int i=1; i<=n; i++)
		{
			da=new Integer (lee.nextInt());
			x.adicionar(da);
		}
		x.mostrar();
		Object max;
		int maxi;
		CSNormal ax =new CSNormal (100);
		max=x.eliminar();
		maxi=max.hashCode();
		
		
		while(!x.esVacia())
		{
			da=x.eliminar();
			ax.adicionar(da);
			int dai =da.hashCode();
			if(dai>maxi)
			{
				maxi=dai;
				max=da;
			}
		}
		while(!ax.esVacia())
		{
			da=ax.eliminar();
			dai=da.hashCode();
			if(da.equals(max))
			{
				dai=dai+1;
				da=new Integer(maxi);
				x.adicionar(da);
			}
			else x.adicionar(da);
		}

	}

}

package colas;

public abstract class CSimple {
	protected int ini,fin,max;
	protected Object v[]=new Object[100];
	
	CSimple(int ve)
	{
		ini=0;
		fin=0;
		max=ve;
	}
	abstract boolean esLlena();
	abstract boolean esVacia();
	abstract void adicionar(Object ele);
	abstract Object eliminar();
	abstract void mostrar();
	abstract int nElem();
	

}
